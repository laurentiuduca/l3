sudo ./xvcpi -c 17 -m 4 -i 22 -o 27
