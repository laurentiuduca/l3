################################################################################
#
# Patch the linux kernel with grlib driver package extension
#
################################################################################

LINUX_EXTENSIONS += grlib-drvpkg

define GRLIB_DRVPKG_PREPARE_KERNEL
	if test -d $(LINUX_DIR)/drivers/grlib/; then \
		echo "Your kernel already supports the GRLIB driver package."; \
		exit 1; \
	fi

	cp -dpfr $(GRLIB_DRVPKG_DIR)/kernel/drivers/grlib $(LINUX_DIR)/drivers ; \
	sed -i '/endmenu/i source "drivers/grlib/Kconfig"' \
		$(LINUX_DIR)/drivers/Kconfig 
	echo 'obj-y += grlib/' >> $(LINUX_DIR)/drivers/Makefile
endef
