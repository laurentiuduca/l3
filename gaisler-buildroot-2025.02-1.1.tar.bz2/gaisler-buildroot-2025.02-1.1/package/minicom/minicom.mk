################################################################################
#
# minicom
#
################################################################################

MINICOM_VERSION = 2.9
MINICOM_SOURCE = minicom-$(MINICOM_VERSION).tar.bz2
MINICOM_SITE = \
	https://salsa.debian.org/minicom-team/minicom/-/archive/$(MINICOM_VERSION)
MINICOM_LICENSE = GPL-2.0+
MINICOM_LICENSE_FILES = COPYING
MINICOM_CPE_ID_VALID = YES

MINICOM_DEPENDENCIES = ncurses $(if $(BR2_ENABLE_LOCALE),,libiconv) \
	$(TARGET_NLS_DEPENDENCIES) host-pkgconf

MINICOM_CONF_OPTS = \
	--enable-dfl-port=/dev/ttyS1 \
	--enable-lock-dir=/var/lock

$(eval $(autotools-package))
