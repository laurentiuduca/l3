################################################################################
#
# libcue
#
################################################################################

LIBCUE_VERSION = 2.3.0
LIBCUE_SITE = $(call github,lipnitsk,libcue,v$(LIBCUE_VERSION))
LIBCUE_LICENSE = GPL-2.0, BSD-2-Clause (rem.c)
LIBCUE_LICENSE_FILES = LICENSE
LIBCUE_DEPENDENCIES = host-bison host-flex flex
LIBCUE_INSTALL_STAGING = YES
LIBCUE_CPE_ID_VENDOR = lipnitsk

$(eval $(cmake-package))
