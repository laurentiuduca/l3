This design is tailored to the Lattice Certus-NX Versa Evaluation board
---------------------------------------------------------------------

= Introduction =

This directory contains a template design for the Certus-NX Versa Evaluation
board (EVB). The EVB is limited in terms of logic resources on the FPGA but
features DDR3 memory and quite some peripherals

To be able to use the lattice ddr3 memory controller make sure that the 
"IP Evaluation" box is enabled under Project > Active Strategy > Bitstream 
setting, in radiant tool. Note that the bitstream will run for 2-4 hours. 

= Design configuration =

There are few variables that can be used to provide basic/additional
components to the design.

BOARD
	folder name inside boards/ where files needed for the design are stored.

LATTICE_IP
	list the Lattice IPs that you want to get included in the design.
	The corresponding cfg files need to be present inside the folder
	boards/lattice-lfd2nx-versa-evn. Each IP needs to be listed as path to
	the cfg file inside the lattice_ips/ folder. When running "make
	radiant-launch" or "make radiant" the IP cfg will be copied inside the
	design folder and the IP generated. No need to manually generate
	it. Currently the only IP listed is pll_125i_62_5o, which is configured to
	take the 125MHz clock signal from an external oscillator and output the
	clock signal for the design.

Design clock frequency: 50 MHz
In the current design configuration, the clock frequency can be increased to
62.5MHz. With 50MHz however, the user have more freedom to experiment,
e.g. increasing the AHBRAM to 128KB while setting LEON3 in MIN configuration.

To trigger a reset of the Leon3 processor, the user can press button SW2

== Lattice server IPs =

Some designs use Lattice IPs that are distributed from Lattice's own IP
server (e.g. the DDR3 memory controller) rather than bundled with a Radiant
install. These are not redistributed with GRLIB and are not downloaded automatically.

To build a design that needs one of these IPs:

1 Download the vlnv.ipk package for the IP yourself(the exact vlnv needed by a given design is listed in
  its `LATTICE_COM_IP' Makefile variable), or obtain a copy from Lattice or your team through whatever channel your organization uses.
2 Place it somewhere on disk, either as the downloaded vlnv.ipk file or as an already-extracted vlnv> folder.
3 Point the design's build at that location by setting `LATTICE_COM_IP_FOLDER` in the design's Makefile.

`LATTICE_COM_IP_FOLDER` is checked before anything else; if the IP isn't
found there (or in the design's local `lattice_ips/` from a previous run),
the build stops with an error explaining what's missing.

= Cores instantiated =

- AHBRAM with 64KB
- SPIMCTRL is instantiated with pins already connected to the SPI Flash memory
  pins
- GRCAN is instantiated but the in/out signals are NOT connected as it depends
  on the board the user wants to connect to the Versa board
- GRGPIO is instantiated controlling the following pins
  * LED_4 to LED_7
  * All 8 PMOD0 pins
  * All 4 DIP switches


= Configuration of environment =

The environment variables for using Radiant in command line mode must
be set:

- $PATH must include the Radiant software executables
- $PATH must include Mentor/QuestaSim

Optional settings that affect behaviour of commands:

GRLIB_LATTICE_RADIANT_SIM_PATH
        simulation tool executable folder. If unset then the script
        will try with the Radiant ModelSim installation.

GRLIB_LATTICE_RADIANT_PERFORMANCE
        default value "9_High-Performance_1.0"

GRLIB_LATTICE_RADIANT_SYNTHESIS
        synthesis tool selection. "synplify" or "lse", default is
        "synplify"

GRLIB_LATTICE_RADIANT_SIM_DEVICE
        selects devices for which simulation libraries are built.
        set to lifcl in the template design Makefile, as the lfd2nx library
        gets compiled as lifcl by Radiant (as they are the same)


= Tested Software =
For design building: Radiant 2023.1
For simulation: ModelSim 10.7g


= Simulation =

Simulation requires simulation librares to be installed. This can be
done via the command:

           make install-radiant-simlibs

The above commnd builds the simulation libraries. These then need to
be mapped into the local ModelSim/Questa project:

           make map-radiant-simlibs
If lattice simulation libraries were not compiled yet
(i.e. install-radiant-simlibs not run), then the system will
build them before mapping.

After that, simulation can be run by:

           make sim
           make sim-launch


= Synthesis =

Radiant can use LSE or Synplify Pro for synthesis. Synplify Pro is the
recommended tool and is the default option.

Full automatic synthesis is launched by running:

	  make radiant

To open the design for possible editing and synthesis:

          make radiant-launch

Followed by using the GUI to start the flow and generate a FPGA
programming file.


= Programming the FPGA =

The programming part is done by using Radiant Programmerm which can be
launched from Radiant itself.

To connect to Lattice boards (for programming purposes), you'll need to use
the D2XX drivers (ftdichip.com). While on Windows system their installation is
automatically handled by the system, on Linux systems you'll need to install
them manually (if not provided in any repository). If you install them
manually, you'll need to disable the kernel ftdi modules (ftdi_sio) before
programming the fpga, otherwise Radiant won't be able to see the FTDI
connections. After programming, you'll need to reload them if you use grmon
with default settings.

To unload ftdi_sio drivers
        sudo modprobe -r ftdi_sio

To load ftdi_sio drivers
        sudo modprobe ftdi_sio


= PC Debug connection =

A debug connection to the design can be establish by just using the USB
connection used for programming the board.

Debug connections can be made either through JTAG (via the AHBJTAG core) or
through UART (via the AHBUART core). But this requires the corresponding core
to be instantiated (check config.vhd). In a Linux environment connecting
through JTAG requires the ftdi_sio module to be unloaded, same as wehn
programming the FPGA. On the other hand, when connecting through UART in a
Linux environment remember to reload the ftdi_sio module before connecting.

Command to connect GRMON through JTAG:
     grmon -ftdi

Command to connect GRMON through UART:
	   grmon -uart /dev/ttyUSBx
with x being the number related to the UART connection. Remember that the uart
part is connected to the B part of the FTDI chip, therefore you'll need to use
the second occurrence of the ttyUSB pair that appears.


EOF
